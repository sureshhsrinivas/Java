/*package com.company;

public class UserDefinedExce extends  Exception {
    int[] arr=new int[5];
    try{
        //System.out.println(arr[5]);
        throw new userDefinedException("this is user Expection");
    }
    catch(userDefinedException ue){
        System.out.println(ue.getmessa
    }

}
*/