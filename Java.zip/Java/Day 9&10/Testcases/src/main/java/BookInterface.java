import java.sql.SQLException;

public interface BookInterface {
    public static void addBook() throws SQLException{

    }
    public static void deleteBooks() throws  SQLException{

    }
    public static void displayBooks() throws  SQLException{

    }
    public static void updateBook() throws SQLException{

    }

}
//Book Sore
//BookTable(,bookname(pri),prize(float),number of copy(int),writer,year of publish