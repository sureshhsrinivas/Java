import java.sql.SQLException;

public interface UserInterface {
    public static void addUser() throws SQLException{

    }

    public static void deleteUser() throws  SQLException{

    }
    public static void updateUser() throws SQLException{

    }
    public static void displayUser() throws  SQLException{

    }
}
//usertable(userid(prim),username,pass,place)