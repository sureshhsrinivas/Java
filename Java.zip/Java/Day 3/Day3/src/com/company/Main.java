//Encapsulation
//Inheritance
//superclass/ Parent class
//Sub class/ Child class
//Advantages: Reusability,
package com.company;

import com.company.Animal;

public class Main {

    public static void main(String[] args) {
	// write your code here
        New student= new New();
        student.display();
        System.out.println(student.name);
        System.out.println(student.sid);
        /*System.out.println("hii");
        Animal an= new Animal();


        cat ca= new cat();
        ca.sound();
        System.out.println(+ca.num); */

    }
}
