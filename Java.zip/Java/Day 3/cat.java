package com.company;

public class cat extends com.company.Animal {
    int num=40;
    public void display(){
        String name;
        String sid;
        eat();
    System.out.println("meow..meow..");
}

}
