package com.company;
public interface UserInterface {
        public void option();
        public void book();
        public void details();
        public void remove();

    }

