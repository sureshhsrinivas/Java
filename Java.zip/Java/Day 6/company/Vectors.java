package com.company;

import java.util.Vector;

public class Vectors {
    //One diminsion axis is called vector
    /*[1
    2
    3
    4
    5
    6
    7]
     */
    Vector<Integer> vector= new Vector<Integer>();
    //[1,2,3,4] //[1] [1+2+2+4+3+6+4+8] [30,42]
    //[2,3,4,5] //[2] [2+4+3+6+4+8+5]

}
