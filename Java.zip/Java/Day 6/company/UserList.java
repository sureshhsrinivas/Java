package com.company;

public class UserList {
    private User[] items = new User[10];
    private int count;
}
