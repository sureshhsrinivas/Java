package com.company;

public interface Atm {
    public void withdraw();
}
