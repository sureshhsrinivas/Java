package com.company;

public interface StudentsUpdate {
    public void marks();
    public void sem();
    public abstract void name();
    static void place(){
        System.out.println("bangalore");
    }

    }

    //

