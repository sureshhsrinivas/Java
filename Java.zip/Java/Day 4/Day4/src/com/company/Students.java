package com.company;

public class Students implements student,StudentsUpdate{
    public void name(){

    }
    public void id(){

    }
    public void collegename(){

    }
    public void branch(){

    }
    public void marks(){

    }
    public void sem(){

    }
    static void place(){

    }

}
