package com.company;
//Interface- Blueprint of class
// We can only use abstract methods and static variables
public interface student {
    public abstract void name();
    public abstract void id();
    public abstract void collegename();
    void branch();

}
