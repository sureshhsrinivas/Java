package com.company;

public interface Example1 {
    public void draw_money();
    public void Dep_money();
}
